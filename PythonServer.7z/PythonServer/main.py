import os
import random
import string
from fastapi import FastAPI, Response
from fastapi.responses import StreamingResponse
import uvicorn

app = FastAPI()


@app.get("/download")
async def download_file(range: str = None):
    filename = "example.txt"  # 要下载的文件名
    file_path = "/path/to/example.txt"  # 文件路径

    # 生成随机内容
    content = generate_random_content(1024 * 1024 * 5)  # 生成 5MB 的随机内容

    start_byte = 0
    end_byte = None

    if range:
        range_header = range.replace("bytes=", "")
        start_end = range_header.split("-")
        start_byte = int(start_end[0])
        if start_end[1]:
            end_byte = int(start_end[1])

    file_size = len(content)

    if start_byte >= file_size:
        # 请求的起始字节超过文件大小，返回 416 Range Not Satisfiable
        return Response(status_code=416)

    if not end_byte or end_byte >= file_size:
        end_byte = file_size - 1

    content_length = end_byte - start_byte + 1

    headers = {
        "Content-Range": f"bytes {start_byte}-{end_byte}/{file_size}",
        "Content-Length": str(content_length),
        "Accept-Ranges": "bytes",
    }

    content = content[start_byte:end_byte+1]

    return Response(content, headers=headers, media_type="application/octet-stream")

def generate_random_content(size):
    return ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase + string.digits, k=size))


@app.get("/str")
def read_root():
    return {'str':"春眠不觉晓"}


if __name__ == '__main__':
    uvicorn.run(app='main:app', host='0.0.0.0', port=2333, reload=False)